# JARVIS OS V3 — GitHub Build Ready

This is a standard Android Gradle project.

## Build on GitHub
1. Upload the contents of this ZIP to a GitHub repository.
2. Open **Actions**.
3. Select **Build JARVIS OS V3 APK**.
4. Run the workflow.
5. When it finishes, open the run and download the artifact named `jarvis-os-v3-apk`.

## Important
The `app/` directory is required by this Android Gradle project. Removing it breaks the Android module configuration.

This version builds the current JARVIS HUD app. Camera/MediaPipe pinch detection is not yet fully wired into the Kotlin activity; the current app includes the HUD and a touch fallback for testing the pinch action path.
