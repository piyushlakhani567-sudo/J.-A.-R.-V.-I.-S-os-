# JARVIS OS v3 — ARC REACTOR + PINCH HUD

This version adds the hand-control interaction path:
- Camera permission
- MediaPipe Tasks Vision dependency
- Pinch detection event path (thumb + index)
- Pinch toggles the Arc Reactor/HUD state
- Open/release gesture resets the HUD state
- Touch fallback for testing on devices where camera tracking is unavailable

For production camera tracking, feed CameraX frames into MediaPipe Hand Landmarker,
calculate normalized thumb-tip/index-tip distance, and call:
  onPinchDetected() when the distance crosses the pinch threshold
  onPinchReleased() when it rises above the release threshold

Use hysteresis (different press/release thresholds) to prevent flicker.

Security:
Hand gestures only control actions explicitly exposed by JARVIS. Protected phone/app/device
actions must continue to require Android permissions and the user's authorization.
