package com.jarvis.os

import android.Manifest
import android.app.Activity
import android.os.Bundle
import android.content.pm.PackageManager
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.MotionEvent
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var status: TextView
    private lateinit var reactor: TextView
    private lateinit var gesture: TextView
    private var security = true
    private var rage = false
    private var reactorActive = false
    private var pinchLatched = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        tts = TextToSpeech(this, this)
        buildHud()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 11)
    }

    private fun buildHud() {
        val bg = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 24, 24, 20)
            setBackgroundColor(Color.rgb(3,7,14))
        }
        status = TextView(this).apply {
            text = "● JARVIS ONLINE"
            textSize = 22f; setTextColor(Color.CYAN); gravity = Gravity.CENTER
        }
        reactor = TextView(this).apply {
            text = "◉"
            textSize = 100f; setTextColor(Color.CYAN); gravity = Gravity.CENTER
            setOnClickListener { toggleReactor() }
        }
        gesture = TextView(this).apply {
            text = "HAND GESTURE: READY\nPinch thumb + index finger"
            textSize = 15f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
            setPadding(0,10,0,20)
        }
        val listen = Button(this).apply {
            text = "🎙  SPEAK TO JARVIS"
            setOnClickListener { listen() }
        }
        val securityBtn = Button(this).apply {
            text = "🛡  SECURITY MODE"
            setOnClickListener { security = !security; updateMode() }
        }
        val rageBtn = Button(this).apply {
            text = "⚡  RAGE / ALERT MODE"
            setOnClickListener { rage = !rage; updateMode(); speak(if(rage) "Alert mode activated." else "Alert mode deactivated.") }
        }
        val cameraBtn = Button(this).apply {
            text = "✋  HAND CONTROL"
            setOnClickListener {
                gesture.text = "HAND CONTROL ACTIVE\nPinch = select / activate\nOpen palm = release"
                speak("Hand control active. Pinch to select.")
            }
        }
        bg.addView(status)
        bg.addView(reactor, LinearLayout.LayoutParams(-1,0,1f))
        bg.addView(gesture)
        bg.addView(listen); bg.addView(cameraBtn); bg.addView(securityBtn); bg.addView(rageBtn)
        setContentView(bg)
        // Touch fallback for testing the same pinch action path.
        bg.setOnTouchListener { _, event ->
            if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                onPinchDetected()
                true
            } else if (event.actionMasked == MotionEvent.ACTION_UP) {
                onPinchReleased()
                true
            } else false
        }
    }

    private fun onPinchDetected() {
        if (!pinchLatched) {
            pinchLatched = true
            toggleReactor()
            gesture.text = "✋ PINCH DETECTED\nARC REACTOR TOGGLED"
        }
    }

    private fun onPinchReleased() {
        pinchLatched = false
        gesture.text = "HAND CONTROL ACTIVE\nPinch = select / activate\nOpen palm = release"
    }

    private fun toggleReactor() {
        reactorActive = !reactorActive
        reactor.text = if (reactorActive) "◉" else "◎"
        status.text = if (reactorActive) "● ARC REACTOR • ACTIVE" else "● JARVIS ONLINE"
        speak(if (reactorActive) "Arc reactor active." else "Arc reactor standby.")
    }

    private fun updateMode() {
        val s = if (security) "SECURITY MODE • ACTIVE" else "SECURITY MODE • OFF"
        gesture.text = s + if(rage) "\n⚡ RAGE / ALERT MODE • ACTIVE" else "\nHAND GESTURE: READY"
    }

    private fun listen() {
        val i = android.content.Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
        startActivityForResult(i, 20)
    }

    override fun onActivityResult(r:Int, c:Int, d:android.content.Intent?) {
        super.onActivityResult(r,c,d)
        if(r == 20 && c == RESULT_OK) {
            val text = d?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: return
            status.text = "● COMMAND: $text"
            speak("Command received. $text")
        }
    }

    private fun speak(s:String) { tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "jarvis") }
    override fun onInit(code:Int) { if(code == TextToSpeech.SUCCESS) tts.language = Locale.getDefault() }
    override fun onDestroy() { tts.shutdown(); super.onDestroy() }
}
